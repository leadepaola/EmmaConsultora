<footer>
    <div class="footer-content">
        <img src="assets/images/LOGO-MODIFICADO.png" width="130px" alt="">
        <!-- <h3>EMMA</h3> -->
        <p>Contactanos por nuestras redes</p>
        <ul class="socials">
            <li><a href="https://www.facebook.com/emmaconsultora" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://wa.me/+5491125215377?text=Hola, quiero hacer una consulta" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
            <li><a href="https://www.instagram.com/consultoraemma" target="_blank"><i class="fab fa-instagram"></i>
            <li><a href="mailto:emmatalentos@gmail.com?Subject=Hola,%20quiero%20hacer%20una%20consulta"><i class="far fa-envelope"></i></a></li>
        </ul>
    </div>
    <div class="footer-bottom">
        <p>copyright &copy;2021, designed by <a href="https://www.lowcostweb.com.ar/"  target="_blank"><span>LowCostWeb</span></a></p>
    </div>
</footer>

